package com.local.guider.dto

class CreateRazorpayOrder {
    var amount: Int? = null
    var currency: String? = null
    var receipt: String? = null
}
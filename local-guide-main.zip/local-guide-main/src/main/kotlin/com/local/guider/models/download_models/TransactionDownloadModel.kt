package com.local.guider.models.download_models

class TransactionDownloadModel {
    var transaction_Id: Long = 0
    var applicant_Id: Long? = null
    var applicant_Name: String? = null
    var applicant_Role: String? = null
    var amount: Double? = null
    var payment_Status: String? = null
    var payment_Token: String? = null
    var created_On: String? = null
}
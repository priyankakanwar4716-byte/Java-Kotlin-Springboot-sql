package com.local.guider.models.response

class AdminDashboard {
    var totalUsers: Long? = null
    var totalPlaces: Long? = null
    var totalGuiders: Long? = null
    var totalPhotographers: Long? = null
    var pendingWithdrawals: Long? = null
    var totalTransactions: Long? = null
}
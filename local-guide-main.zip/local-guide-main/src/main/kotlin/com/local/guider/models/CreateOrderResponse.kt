package com.local.guider.models


import com.google.gson.annotations.SerializedName

data class CreateOrderResponse(
    @SerializedName("amount")
    var amount: Int? = null,
    @SerializedName("amount_due")
    var amountDue: Int? = null,
    @SerializedName("amount_paid")
    var amountPaid: Int? = null,
    @SerializedName("attempts")
    var attempts: Int? = null,
    @SerializedName("created_at")
    var createdAt: Int? = null,
    @SerializedName("currency")
    var currency: String? = null,
    @SerializedName("entity")
    var entity: String? = null,
    @SerializedName("error")
    var error: Error? = null,
    @SerializedName("id")
    var id: String? = null,
    @SerializedName("notes")
    var notes: List<Any?>? = null,
    @SerializedName("offer_id")
    var offerId: Any? = null,
    @SerializedName("receipt")
    var receipt: String? = null,
    @SerializedName("status")
    var status: String? = null
)
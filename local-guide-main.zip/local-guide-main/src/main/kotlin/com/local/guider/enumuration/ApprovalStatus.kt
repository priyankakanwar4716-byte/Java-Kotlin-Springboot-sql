package com.local.guider.enumuration;

enum class ApprovalStatus(val value: String) {
 IN_REVIEW("In Review"),
 DECLINED("Declined"),
 APPROVED("Approved")
}
